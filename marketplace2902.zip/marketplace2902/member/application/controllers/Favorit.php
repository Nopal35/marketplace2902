<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Favorit extends CI_Controller {

    public function __construct(){
        parent::__construct();

        if (!$this->session->userdata('id_member')) {
            redirect('/', 'refresh');
        }

        $this->load->model('Favorit_model');
        $this->load->library('session');
    }

    // Tambah produk ke favorit
    public function tambah($id_produk){
        $id_member = $this->session->userdata('id_member');
        if(!$id_member){
            redirect('login');
        }

        $this->Favorit_model->tambah_favorit($id_member, $id_produk);
        redirect($_SERVER['HTTP_REFERER']);
    }

    // Lihat daftar favorit
    public function lihat(){
        $id_member = $this->session->userdata('id_member');

        $data['favorit'] = $this->Favorit_model->get_favorit_member($id_member);

        $this->load->view('header');
        $this->load->view('favorit_tampil', $data);
        $this->load->view('footer');
    }

    // Hapus favorit
    public function hapus($id_favorit){
        $this->Favorit_model->hapus_favorit($id_favorit);

        $this->session->set_flashdata('pesan_sukses', 'Produk dihapus dari favorit.');
        redirect('favorit/lihat', 'refresh');
    }
}
