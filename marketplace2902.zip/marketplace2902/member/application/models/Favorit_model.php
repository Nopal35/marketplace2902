<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Favorit_model extends CI_Model {

    public function tambah_favorit($id_member, $id_produk){
        $data = array(
            'id_member' => $id_member,
            'id_produk' => $id_produk
        );
        $this->db->insert('favorit', $data);
    }

    public function get_favorit_member($id_member){
        $this->db->select('favorit.id_favorit, produk.*');
        $this->db->from('favorit');
        $this->db->join('produk', 'produk.id_produk = favorit.id_produk');
        $this->db->where('favorit.id_member', $id_member);
        $query = $this->db->get();
        return $query->result();
    }

    public function hapus_favorit($id_favorit){
        $this->db->where('id_favorit', $id_favorit);
        $this->db->delete('favorit');
    }
}
