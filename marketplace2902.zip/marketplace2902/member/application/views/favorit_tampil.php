<div class="container py-4">
    <h3 class="mb-4 text-center">Produk Favorit Saya</h3>

    <!-- Tampilkan flash message -->
    <?php if ($this->session->flashdata('pesan_sukses')): ?>
        <div class="alert alert-success text-center">
            <?php echo $this->session->flashdata('pesan_sukses'); ?>
        </div>
    <?php endif ?>

    <!-- Tombol kembali -->
    <div class="text-center mb-4">
        <a href="<?php echo site_url('/'); ?>" class="btn btn-secondary">
            ⬅️ Kembali ke Home
        </a>
    </div>

    <?php if (empty($favorit)): ?>
        <div class="alert alert-secondary text-center">
            <a href="<?php echo base_url('produk') ?>" class="btn btn-primary">Belum Ada Yang Istimewa, Ayo Kantongin Sekarang!!</a>
        </div>
    <?php else: ?>
        <table class="table table-sm table-bordered align-middle text-center">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Foto</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; foreach($favorit as $produk): ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td>
                        <img src="<?php echo $this->config->item('url_produk').$produk->foto_produk; ?>" 
                             alt="<?php echo $produk->nama_produk; ?>" 
                             style="width: 70px; height: 70px; object-fit: cover;">
                    </td>
                    <td><?php echo $produk->nama_produk; ?></td>
                    <td>Rp <?php echo number_format($produk->harga_produk, 0, ',', '.'); ?></td>
                    <td>
                        <a href="<?php echo site_url('produk/detail/'.$produk->id_produk); ?>" 
                           class="btn btn-sm btn-primary mb-1">🛒 Beli</a>
                        <a href="<?php echo site_url('favorit/hapus/'.$produk->id_favorit); ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Yakin hapus dari favorit?')">🗑️ Hapus</a>
                    </td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    <?php endif ?>
</div>
