<div class="container py-4">
    <h5 class="mb-4 text-center">
        <?php echo isset($judul) ? $judul : 'Data Produk'; ?>
    </h5>

    <div class="row g-4">
        <?php if (empty($produk)): ?>
            <div class="col-12 text-center">
                <p class="text-muted">Produk</p>
            </div>
        <?php else: ?>
            <?php foreach ($produk as $value): ?>
                <div class="col-12 col-sm-6 col-md-4">
                    <div class="card h-100 shadow-sm border-0">
                        <a href="<?php echo base_url("produk/detail/".$value["id_produk"]) ?>" class="text-decoration-none text-dark">
                            <img src="<?php echo $this->config->item("url_produk").$value['foto_produk'] ?>"
                                 class="card-img-top img-fluid"
                                 style="height: 250px; object-fit: cover; border-bottom: 1px solid #ddd;">
                            <div class="card-body text-center">
                                <h6 class="card-title"><?php echo $value['nama_produk'] ?></h6>
                                <a href="<?php echo site_url('favorit/tambah/'.$value['id_produk']); ?>" 
                                    class="btn btn-sm btn-outline-danger mt-2">
                                    ❤️ Favorit
                                        </a>
                                <p class="lead mb-0">Rp <?php echo number_format($value['harga_produk'], 0, ',', '.') ?></p>
                            </div>
                        </a>
                    </div>
                </div>
            <?php endforeach ?>
        <?php endif ?>
    </div>
</div>
