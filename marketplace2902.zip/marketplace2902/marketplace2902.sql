-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 14 Jul 2025 pada 20.14
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marketplace2902`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `nama`) VALUES
(1, 'nopal@gmail.com', '40bb6a0711def0926782a09be58a11c4cf68c698', 'nopall, S.kom');

-- --------------------------------------------------------

--
-- Struktur dari tabel `artikel`
--

CREATE TABLE `artikel` (
  `id_artikel` int(11) NOT NULL,
  `judul_artikel` varchar(255) NOT NULL,
  `isi_artikel` text NOT NULL,
  `foto_artikel` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `artikel`
--

INSERT INTO `artikel` (`id_artikel`, `judul_artikel`, `isi_artikel`, `foto_artikel`) VALUES
(6, 'Cowok Kece Wajib Punya! Ini Gaya Keren Pakai Converse', '<p>Sepatu Converse putih memang nggak pernah gagal bikin penampilan makin kece. Warna netral dan desain klasiknya bikin sepatu ini cocok dipadukan dengan berbagai gaya outfit, baik cowok maupun cewek.</p>\r\n\r\n<p>Kalau kamu suka gaya kasual santai, cukup padukan Converse putih dengan celana jeans sobek dan kaus polos. Simpel, tapi tetap stylish dan nggak ribet. Buat yang suka tampil sedikit edgy, coba padukan dengan jaket kulit atau oversized denim jacket. Converse putih juga cocok buat kamu yang suka tampilan clean dan minimalis &mdash; tinggal pakai celana chino warna netral dan kemeja putih, langsung terlihat rapi tapi tetap santai.</p>\r\n\r\n<p>Untuk cewek, gaya feminin juga bisa banget! Padukan Converse putih dengan dress floral atau midi skirt untuk tampilan yang manis tapi tetap casual. Mau tampilan streetwear? Celana cargo, hoodie, dan Converse putih jawabannya.</p>\r\n\r\n<p>Intinya, sepatu Converse putih itu serbaguna banget. Mau gaya santai, edgy, chic, sampai semi-formal, semua bisa kamu eksplor. Tinggal mix &amp; match sesuai mood dan kepribadian kamu.</p>\r\n', 'foto1.png'),
(7, 'Converse High Kece', '<p>Converse High-top jadi pilihan wajib buat kamu yang mau tampil kasual tapi tetap kece. Dengan desain klasik yang ikonik, sepatu ini cocok dipadukan dengan jeans, celana kargo, atau bahkan rok buat yang mau tampil edgy. Warna putih atau hitam jadi favorit, tapi warna-warna bold juga nggak kalah keren buat statement look.</p>\r\n\r\n<p>Sepatu ini nggak cuma nyaman, tapi juga jadi simbol gaya anak muda yang bebas dan kreatif. Mau nongkrong, ke kampus, atau sekadar jalan santai, Converse High siap bikin penampilan kamu makin standout. Simple, timeless, dan pastinya selalu <em>on point</em>!</p>\r\n', 'foto2.png'),
(8, 'Tampil Kece dengan Berbagai Gaya Sepatu Converse', '<p>Sepatu Converse selalu jadi pilihan kece untuk segala gaya, dengan berbagai model yang bisa disesuaikan dengan karakter dan kebutuhan kamu. Converse High-top cocok buat tampilan streetwear atau kasual edgy, apalagi dipadukan dengan jeans robek atau jaket denim. Untuk gaya santai, Converse Low-top jadi andalan saat hangout atau ngampus, apalagi kalau dipasangkan dengan chino atau celana pendek. Kalau kamu mau tampil lebih tinggi dan beda, Converse Platform siap menunjang gaya feminim atau street style kamu. Sementara itu, Converse All Star 70s hadir dengan nuansa retro dan bahan premium, pas buat yang suka gaya klasik dan berkelas. Apa pun pilihanmu, sepatu Converse selalu berhasil bikin penampilan kamu makin keren dan percaya diri.</p>\r\n', 'foto3.png'),
(9, 'Tampil Kece Ala Cewek Aktif dengan Sepatu Converse', '<p>Cewek kece makin lengkap gayanya dengan sepatu Converse yang simple tapi tetap stylish. Mau tampil kasual, sporty, sampai edgy, Converse selalu jadi pilihan tepat. Padukan Converse High-top dengan rok mini dan oversized jacket buat look yang edgy dan kekinian. Kalau mau tampil santai tapi tetap modis, Converse Low-top cocok banget dipakai bareng celana jeans atau kulot. Buat gaya yang lebih unik dan standout, Converse Platform bisa jadi pilihan kece, apalagi kalau dipadu dengan dress atau jumpsuit. Dengan berbagai model dan warna, Converse bikin setiap langkah cewek makin percaya diri dan stylish tanpa harus ribet.</p>\r\n', 'foto41.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `favorit`
--

CREATE TABLE `favorit` (
  `id_favorit` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `favorit`
--

INSERT INTO `favorit` (`id_favorit`, `id_member`, `id_produk`, `created_at`) VALUES
(8, 2, 39, '2025-07-15 00:13:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL,
  `foto_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`, `foto_kategori`) VALUES
(11, 'Sepatu Cowo', 'converse_chuck_taylor_70.jpg'),
(12, 'Limited Edtion', 'Limited_edition_converse_looney.jpg'),
(13, 'Sepatu Cewe', 'converse_wedges_high_import.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `id_member_jual` int(11) NOT NULL,
  `id_member_beli` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `id_member` int(11) NOT NULL,
  `email_member` varchar(100) NOT NULL,
  `password_member` varchar(100) NOT NULL,
  `nama_member` varchar(100) NOT NULL,
  `alamat_member` text NOT NULL,
  `wa_member` varchar(50) NOT NULL,
  `kode_distrik_member` varchar(10) NOT NULL,
  `nama_distrik_member` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`id_member`, `email_member`, `password_member`, `nama_member`, `alamat_member`, `wa_member`, `kode_distrik_member`, `nama_distrik_member`) VALUES
(1, 'naufal@amikom.ac.id', '745de6038585a515fcd174f25ad92eef50de7b0a', 'naufal fadhil asad', 'jawa tengah cilacap', '088232388018', '363', 'Kabupaten Ponorogo Jawa Timur'),
(2, 'fullngapak@amikom.ac.id', 'fcb4075a3da2c691013f389049e0cb797f17a793', 'fullngapak segara kidul', 'jawa tengah cilacap', '085878151738', '105', 'Kabupaten Cilacap Jawa Tengah'),
(3, 'naufalfadhilasad2gmail.com', '807509605092ce08febf0c156be928b4a3ad998a', 'naufal fadhil asad', 'cilacap', '088232388018', '163', 'Kabupaten Jepara Jawa Tengah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `id_member` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama_produk` varchar(255) NOT NULL,
  `harga_produk` int(11) NOT NULL,
  `foto_produk` varchar(255) NOT NULL,
  `deskripsi_produk` text NOT NULL,
  `berat_produk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `id_member`, `id_kategori`, `nama_produk`, `harga_produk`, `foto_produk`, `deskripsi_produk`, `berat_produk`) VALUES
(21, 2, 13, 'Sepatu Wanita Converse Run Star Hike Pink Quartz High', 1399000, 'sepatu_wanita_converse_run_star_hike_pink_quartz_high.png', 'STOK TERBATAS\r\n\r\n\r\n\r\nConverse Run Star Hike Hi Pink Quartz\r\n\r\n\r\n\r\nBrand New In Box\r\n\r\n100% Original. Barang resmi Converse Store (PT MAP)\r\n\r\n\r\n\r\nAvailable size\r\n\r\n3 us / 35 eur / 21cm\r\n\r\n4 us / 36 eur / 22cm\r\n\r\n4.5 us / 37 eur / 22.5cm\r\n\r\n5.5 us / 38 eur / 23.5cm\r\n\r\n6.5 us / 39 eur / 24.5cm\r\n\r\n7 us / 40 eur / 25cm\r\n\r\n\r\n\r\nTidak kw, premium, grade A/B, atau sejenisnya.\r\n\r\nGaransi uang kembali jika kawe.\r\n\r\nBarang resmi terjamin keasliannya.\r\n\r\n\r\n\r\nNotes :\r\n\r\n1. Barang ORIGINAL resmi CONVERSE STORE\r\n\r\n2. Diharapkan melakukan konfirmasi size kepada admin.\r\n\r\n3. Diharapkan melakukan konfirmasi apakah bisa dikirim menggunakan Gojek / Grab sameday maupun instant.\r\n\r\n4. Barang yang dikirim sudah melalui QC dari toko kami.\r\n\r\n5. Refund bisa dilakukan apabila barang terbukti FAKE (KW).\r\n\r\n6. Kami hanya menerima komplain (barang tidak sesuai) apabila disertai video unboxing.\r\n\r\n\r\n\r\nPacking Double box / bubblewarp tebal\r\n\r\nApabila ada yang kurang jelas bisa ditanyakan.\r\n\r\nTerima kasih. Selamat Berbelanja..', 680),
(22, 2, 13, 'Sepatu Sneakers Converse Original Run Star Hike Low Top White', 600000, 'sepatu_sneakers_converse_original_run_star_hike_low_top_white.png', 'Converse Run Star Hike Low Top White/Black/Gum\r\n\r\n\r\n\r\nDetail Produk :\r\n\r\n????Gender : Unisex\r\n\r\n????Material : Kanvas\r\n\r\n????Size : EUR/U.K/CM\r\n\r\n35/2.5/21 cm\r\n\r\n36/3.5/22 cm\r\n\r\n37/4/22.5 cm\r\n\r\n38/5/23.5 cm\r\n\r\n39/5.5/24.5 cm\r\n\r\n40/6/25 cm\r\n\r\n41/7/26 cm\r\n\r\n42/7.5/26.5 cm\r\n\r\n43/8.5/27.5 cm\r\n\r\n44/9/28 cm\r\n\r\n45/10/29 cm\r\n\r\n????Brand New In Box/BNIB\r\n\r\n????100% Original resmi PT. MAP\r\n\r\nMade In Vietnam\r\n\r\nSKU : 168817C\r\n\r\n\r\n\r\n????LIMITED STOCK????\r\n\r\n\r\n\r\nTata Cara Pemesanan :\r\n\r\n1. Pilih produk yang kamu inginkan\r\n\r\n2. Tanyakan stock size terlebih dahulu sebelum melakukan pemesanan\r\n\r\n3. Pastikan varian size & varian produk yang kalian pilih benar sesuai (size tidak dapat ditukar jikalau produk sudah kami proses atau kirim) \r\n\r\n4. Estimasi pengiriman : 2-3 hari waktu kerja\r\n\r\n5. Jangan sungkan untuk tanya admin jikalau ada informasi produk yang kurang jelas\r\n\r\n\r\n\r\nNote*\r\n\r\n????️ Kualitas produk terjamin. \r\n\r\n????️ Kami hanya menjual produk Original & Resmi. \r\n\r\n????️ Kami tidak menjual produk fake/palsu/kw/imitasi/tiruan/premium & lain sebagainya. \r\n\r\n????️ Kami memberikan garansi, jika produk yang kami jual terbukti tidak Original, maka uang akan kami kembalikan sepenuhnya. \r\n\r\n????️ Pengiriman menggunakan buble wrap sehingga mengurangi damage pada box ketika pengiriman. \r\n\r\n????️ Teliti & Cermat dalam membaca deskripsi.\r\n\r\n\r\n\r\nTerima kasih\r\n\r\n#Converse #ConverseAllStar #ConverseChuckTaylor70s #ChuckTaylor70s #ConverseOriginal #ConverseChuckTaylor #Converse70s #ConverseOneStar #ConverseJackPurcell #ConverseCourtlandt #Converse70s #AllStar #SepatuConverse', 680),
(23, 2, 13, 'Sepatu Converse Run Star Murah Sneaker Cewek Wanita Gaya Keren', 300000, 'sepatu_converse_run_star_murah_sneaker_cewek_wanita_gaya_keren.png', 'PERSEDIAAN SANGAT TERBATAS.\r\n\r\n\r\n\r\n\r\n\r\nSELALU PASTIKAN MENANYAKAN STOK SEBELUM MEMBELI.\r\n\r\n\r\n\r\n\r\n\r\n100% AMANAH\r\n\r\n\r\n\r\n\r\n\r\nJANGAN PERNAH RAGU UNTUK BERBELANJA DI TOKO KAMI. KARENA SEMUA BARANG YANG KAMI JUAL 100% SESUAI BARANG DAN DESKRIPSI (DIJAMIN 100%)\r\n\r\n\r\n\r\n\r\n\r\nUKURAN 36-41\r\n\r\n\r\n\r\n\r\n\r\nBAHAN : KANVAS, WAFFLE DT\r\n\r\n\r\n\r\nKONDISI: NEW/BARANG BARU \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nKELENGKAPAN: SEPATU KANAN KIRI, BOX\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\nDENGAN KALIAN BERTRANSAKSI, KAMI ANGGAP PEMBELI SUDAH MEMAHAMI DAN MENGERTI BARANG MAUPUN KEBIJAKAN YANG BERLAKU DI STORE KAMI.\r\n\r\n\r\n\r\n\r\n\r\nSEBELUM DIKIRIM KAMI PASTIKAN BARANG DICEK TERLEBIH DAHULU, APABILA TERJADI KESALAHAN DIPIHAK PENGIRIM SEPERTI CACAT, SALAH BARANG ATAU UKURAN, KAMI BERTANGGUNG JAWAB PENUH DAN AKAN SEGERA MENGGANTINYA.\r\n\r\n\r\n\r\n\r\n\r\nKHUSUS SEPATU ANAK, TIDAK MENERIMA RETUR\r\n\r\n\r\n\r\n\r\n\r\n_abr22\r\n\r\n\r\n\r\nNOTE:\r\n\r\n\r\n\r\n\r\n\r\nSYARAT RETURN BARANG HARUS MENYERTAKAN VIDEO UNBOXING PAKET (BUAT VIDEO DARI SEBELUM PAKET DIBUKA)\r\n\r\n\r\n\r\n#ermishoes #converse #converserunstarhike #converserunstar #sepatucewek #sepatuwanita #sepatusneakers #sepatusneakerscewek #sepatusneakersmurah', 580),
(24, 2, 13, 'Sepatu Converse Chuck 70 Wanita Baby Pink', 899250, 'sepatu_converse_chuck_70_wanita_baby_pink.png', '•100% Original (PT.MAP)\r\n\r\n•Garansi uang kembali jika terbukti produk yang diterima tidak original\r\n\r\n•Brand New In Box - Fullset (lengkap dengan box dan kelengkapan produk)\r\n\r\n\r\n\r\nPANDUAN UKURAN\r\n\r\n(dapat dilihat pada Tabel Size Guide / Tabel Panduan Ukuran)\r\n\r\n\r\n\r\nSIZE TERSEDIA\r\n\r\n(Dapat dilihat pada Varian Produk, tanyakan terlebih dahulu ketersediaan stok ukuran / warna produk yang diinginkan kepada customer service kami)\r\n\r\n\r\n\r\nORDER\r\n\r\n•Mohon ditanyakan terlebih dahulu ketersediaan size produk yang diinginkan melalui chat ke Admin kami.\r\n\r\n•Mohon dicantumkan size yang dipesan pada catatan pemesanan.\r\n\r\n\r\n\r\nKOMPLAIN dan RETUR\r\n\r\n•Barang yang sudah dibeli tidak dapat ditukar atau dikembalikan apabila kesalahan dilakukan oleh pihak pembeli.\r\n\r\n•Penukaran atau pengembalian barang hanya berlaku apabila produk yang diterima tidak sesuai pesanan / cacat dan wajib menyertakan VIDEO UNBOXING secara utuh dan lengkap pada saat pengajuan komplain.\r\n\r\n•Kami siap membantu jika terjadi kendala pada pengiriman atau masalah produk.\r\n\r\n\r\n\r\nJam Operasional Toko Kami :\r\n\r\nBuka Setiap Hari (Kecuali Hari Libur Nasional)\r\n\r\n10.00 WIB - 21.00 WIB\r\n\r\n\r\n\r\nSelamat Belanja ????\r\n\r\n\r\n\r\nJangan lupa untuk berikan penilaian dan ulasan positifnya setelah belanja di store kami ya ????\r\n\r\n\r\n\r\n#ChardyShop #ChardyStore #Sepatu #SepatuOriginal #Sneakers #SneakersOriginal #Converse #SepatuConverse #ConverseOriginal #ConverseOri #ConverseAuthentic #ConverseAsli #ConverseChuckTaylor #Conversechuck70 #ConversePTMAP #ConversePria #ConverseWanita #SneakersPria #SneakersWanita #ConverseMurah #ConverseDiskon #ConverseOfficial #ConverseOfficialStore #ConverseShopeeMall', 482),
(25, 2, 13, 'Sepatu Converse wedges High Import', 299000, 'converse_wedges_high_import.png', 'SNEAKERS KOREA STYLE 100% IMPORT \r\n\r\n\r\n\r\n+ FREE BOX SEPATU\r\n\r\n+ SETIAP BARANG YANG DIKIRIM SUDAH TERMASUK BOX SEPATU DAN PACKING PLASTIK \r\n\r\n+ UNTUK KOMPLAINAN MOHON MENBUAT VIDEO SAAT UNBOXING UNTUK PROSES CLAIM JIKA BARANG YANG DI TERIMA KURANG/RUSAK\r\n\r\n+ HANYA MELAYANI KOMPLAINAN JIKA DI BERI BINTANG 5 / 4\r\n\r\n\r\n\r\nDeskripsi \r\n\r\nSepatu Sneakers Wanita Import Korea Style Premium Quality \r\n\r\nKODE NS560\r\n\r\n \r\n\r\nBahan Kanvas (Sol Karet)\r\n\r\nTinggi Sol 6 cm\r\n\r\nBerat 1000gram\r\n\r\n\r\n\r\nUkuran :\r\n\r\n- Size 36 kaki 23 cm\r\n\r\n- Size 37 kaki 23.5 cm\r\n\r\n- Size 38 kaki 24 cm\r\n\r\n- Size 39 kaki 24.5 cm \r\n\r\n- Size 40 kaki 25 cm\r\n\r\n\r\n\r\nUNTUK ORDER, MOHON TANYA STOCK TERLEBIH DAHULU SEBELUM ORDER\r\n\r\n\r\n\r\nSEMUA PRODUK BISA DIGABUNG\r\n\r\nKUALITAS PRODUK JAMIN 100% IMPORT\r\n\r\nONGKIR 1 KG MUAT BERAT PRODUK 1.2 KG \r\n\r\n\r\n\r\nWelcome Reseller & Dropshipper\r\n\r\n\r\n\r\n#sepatu #sepatuwanita #sepatusneakers #sneakers #sepatusneakerswanita #sneakerswanita #sneakerscasual #sneakerskasual #sneakerskorea #womensneakers #sneakersimport #sepatuimport #sepatuwanitaimport #sepatusneakerswanitaimport #tasfashion10', 700),
(26, 2, 12, 'Sepatu Converse X Tom&Jerry Chuck 70', 2499000, 'sepatu_converse_x_tomjerry_chuck_70.png', 'Converse X Tom & Jerry Chuck 70 Hi Black Multi Egret Original A15110C\r\n\r\n\r\n\r\nSKU : A15110C\r\n\r\nGender : Unisex\r\n\r\n\r\n\r\n•100% Original (PT.MAP)\r\n\r\n•Garansi uang kembali jika terbukti produk yang diterima tidak original\r\n\r\n•Brand New In Box - Fullset (lengkap dengan box dan kelengkapan produk)\r\n\r\n\r\n\r\nPANDUAN UKURAN\r\n\r\n(hanya panduan ukuran, tanyakan ketersediaan size produk yang diinginkan ke Admin kami)\r\n\r\n37 / 4.5 US / 23.5 cm\r\n\r\n38 / 5.5 US / 24.5 cm\r\n\r\n39 / 6 US / 24.5 cm\r\n\r\n40 / 7 US / 25.5 cm\r\n\r\n41 / 7.5 US / 26 cm\r\n\r\n42 / 8.5 US / 27 cm\r\n\r\n43 / 9.5 US / 28 cm\r\n\r\n44 / 10 US / 28.5 cm\r\n\r\n\r\n\r\nORDER\r\n\r\n•Mohon ditanyakan terlebih dahulu ketersediaan size produk yang diinginkan melalui chat ke Admin kami.\r\n\r\n•Mohon dicantumkan size yang dipesan pada catatan pemesanan.\r\n\r\n\r\n\r\nKOMPLAIN dan RETUR\r\n\r\n•Barang yang sudah dibeli tidak dapat ditukar atau dikembalikan apabila kesalahan dilakukan oleh pihak pembeli.\r\n\r\n•Penukaran atau pengembalian barang hanya berlaku apabila produk yang diterima tidak sesuai pesanan / cacat dan wajib menyertakan VIDEO UNBOXING secara utuh dan lengkap pada saat pengajuan komplain.\r\n\r\n•Kami siap membantu jika terjadi kendala pada pengiriman atau masalah produk.\r\n\r\n\r\n\r\nJam Operasional Toko Kami :\r\n\r\nBuka Setiap Hari (Kecuali Hari Libur Nasional)\r\n\r\n10.00 WIB - 21.00 WIB\r\n\r\n\r\n\r\nSelamat Belanja di Shopee\r\n\r\n\r\n\r\nJangan lupa untuk berikan penilaian dan ulasan positifnya setelah belanja di store kami ya', 450),
(27, 2, 12, 'Sepatu Converse X Shrimps Chuck Taylor All Star 70 Hi', 3000000, 'sepatu_converse_x_shrimps_chuck_taylor_all_star_70_hi.png', 'Stock Habis (Tidak Produksi)', 480),
(28, 2, 12, 'Sepatu Converse 70s X Golf Wang Tri Panel', 3000000, 'sepatu_converse_70s_X_golf_wang_tri_panel.png', 'Converse 70s X Golf Wang Tri Panel\r\n\r\nSize : 36 - 44\r\n\r\nMade in Vietnam', 482),
(29, 2, 12, 'Sepatu Converse 70s Hi Bugs Bunny Edition Premium Original', 24000, 'sepatu_converse_70s_hi_bugs_bunny_edition_premium_original.png', 'EADY!!! Sneakers / Shoes Size Available 37-40 ________________________ Condition : (BNIB) Brand New Include Box Kualitas : High Premium / Mirror Produck : Import 100% Real Picture Camera HP 100% Quarantee 100% Trusted JANGAN LUPA TANYAKAN STOCK MASIH READY ATAU SIZE MASIH ADA.?!! NOTE Untuk Pembeli : Menjual Produck Import Berkualitas High Premium BNIB/ KW Super, Tidak Menjual Produck Lokal Maupun Original Brand..., Garansi Jika Barang Dikirim Berbeda Dengan Fhoto KAMI Siap Menerima KOMPLAIN REFUND UANG KEMBALI 100%,DAN Siap Menerima Return Size Jika stock Masih Ready Batas Waktu 1Hari Jika notif Barang Diterima... Jadilah Pembeli Bijaksana, Memberi Ulasan Sama Dengan Transaksi deal..!!', 482),
(30, 2, 12, 'Sepatu Converse Limited Edition Looney', 279000, 'Limited_edition_converse_looney.png', 'SILAHKAN LANGSUNG DIORDER AJA EA\r\n\r\n#BARANG TERSEDIA SELAMA FOTO MASIH DIPAJANG\r\n\r\n#FREE KAOS KAKI !!!!!!\r\n\r\n#100% HASIL FOTO SENDIRI\r\n\r\n#GA SESUAI FOTO UANG KEMBALI\r\n\r\nDESKRIPSI PRODUK :\r\n\r\nsize : 40-44\r\nBahan : kanvas\r\nSole : rubber\r\nMade in vietnam\r\npremium quality 1:1 like ori', 482),
(31, 2, 11, 'Sepatu Converse All Star Chuck Taylor 70s High Arcive Flame', 899000, 'sepatu_converse_all_star_chuck_taylor_70s_high_arcive_flame.png', 'Converse Run Star Low\r\nREADYSTOCK!\r\n\r\nBRAND NEW INCLUDE BOX (BNIB)\r\nWhite\r\nMade in Vietnam\r\n(Valid & Authorized @Google)\r\n\r\nSize Measurement :\r\n37.5 EUR / 5 US / 24 CM\r\n38 EUR / 5.5 US / 24.5 CM\r\n39.5 EUR / 6.5 US / 25 CM\r\n40 EUR / 7 US / 25.5 CM\r\n41 EUR / 7.5 US / 26 CM\r\n42 EUR / 8.5 US / 27 CM\r\n43 EUR / 9.5 US / 28 CM\r\n44 EUR / 10 US / 28.5 CM\r\n\r\nFREE :\r\n- SOCKS\r\n- SNEAKERS PARFUME\r\n- PAPER BAG\r\n- STICKERS\r\n- DOUBLE BOX PACKING\r\n\r\nNote : *Tanyakan ketersediaan stok terlebih dahulu via personal chat sebelum melakukan proses checkout ya\r\n\r\n\r\n100% REAL PICT GUARANTEE (100% UANG KEMBALI JIKA BARANG TIDAK SESUAI DENGAN FOTO)\r\n100% GARANSI UANG KEMBALI JIKA DITEMUKAN KECACATAN PADA FISIK BARANG\r\n\r\nWhy us :\r\nHARGA TERJANGKAU SE TOKOPEDIA\r\nREPUTASI TOKO SANGAT BAIK\r\nTOTAL 20.000 PCS PRODUK TELAH TERJUAL\r\nAKUMULASI PENILAIAN 4.9/5.0 TERKAIT KUALITAS BARANG ️️️️️\r\nMEMILIKI PENGHARGAAN POWER MERCHANT PRO ULTIMATE DARI TOKOPEDIA\r\nTOKO BERSTATUS SELLER GOLD DAN TERJAMIN PELAYANANNYA\r\n\r\n\r\n*Pengiriman di hari yang sama ketika checkout\r\n*Rekomendasi ekspedisi : JNE, J&T, dan Paxel\r\n\r\nJika masih ragu, silahkan hubungi kami via personal chat terkait kualitas barang maupun ketentuan size, kami akan layani anda secara interaktif dan komunikatif', 482),
(32, 2, 11, 'Sepatu Converse Chuck Taylor All Star Malden Street sneakers Black', 800000, 'sepatu_converse_chuck_taylor_all_star_malden_street_sneakers_black.png', 'Readyy Stock', 400),
(33, 2, 11, 'sepatu senakers converse chuck taylor all star debossed nubuck white', 800000, 'sepatu_senakers_converse_chuck_taylor_all_star_debossed_nubuck_white.png', 'Ready Stock', 482),
(34, 2, 11, 'sepatu converse pria premium ori chuck taylor 70s low parchment egret', 500000, 'sepatu_converse_pria_premium_ori_chuck_taylor_70s_low_parchment_egret.png', 'Kondisi: Baru\r\nMin. Pemesanan: 1 Buah\r\nEtalase: CONVERSE\r\nBrand New Include Box (BNIB)\r\nMade in Vietnam\r\nTag size CM / MM\r\n\r\nSize :\r\nUS 3.5 // EUR 36 // 22.5cm\r\nUS 4.5 // EUR 37 // 23.5cm\r\nUS 5.5 // EUR 38 // 24.5cm\r\nUS 6.0 // EUR 39 // 24,5cm\r\nUS 7.0 // EUR 40 // 25.5cm\r\nUS 8.0 // EUR 41 // 26cm\r\nUS 8.5 // EUR 42 // 27cm\r\nUS 9.5 // EUR 43 // 28cm\r\nUS 10.0 // EUR 44 // 28.5cm\r\n\r\n\r\n- Produk 100% BNIB,, harga & produk terbaik\r\n- Jika menerima produk cacat chat admin\r\n- Pilih ukuran yang sesuai\r\n- Produk yang kamu terima sesuai dengan gambar\r\n-free paperbag dan kaoskaki\r\n\r\nHappy Shoping :)\r\nLihat Lebih Sedikit\r\n', 400),
(35, 2, 11, 'Sepatu Converse Chuck Taylor 70', 550000, 'converse_chuck_taylor_70.png', 'converse chuck 70s hi jarang dipakai, mostly pemakaian indoor kotor sedikit saja di bagian putih krn pemakaian wajar no robek, lem aman, tdk pernah kena basah/hujan NO KW, beli di store langsung with box size 36', 480),
(36, 2, 13, 'Sepatu Converse Run Star Trainer', 1300000, 'sepatu_converse_run_star_trainer.png', 'Kondisi: Baru\r\nMin. Pemesanan: 1 Buah\r\nEtalase: Runstar Trainer\r\nSepatu Converse Run Star Trainer Original \r\n\r\nBNIB Original 100%\r\nSKU CONA08262C\r\n\r\nSize\r\n36\r\n37\r\n38\r\n39\r\n40\r\n41\r\n42\r\n43\r\n44\r\n\r\nMohon untuk menanyakan kesediaan stok terlebih dahulu karena produk tersebut best seller\r\n\r\nMohon untuk memastikan ukurannya \r\n\r\nProduk yang sudah di beli tidak dapat di tukar \r\n\r\nKami hanya menjual produk Original', 680),
(37, 2, 13, 'Sepatu Converse Anak Perempuan Terbaru', 600000, 'sepatu_converse_anak_perempuan_terbaru.png', 'Ready Stockk', 480),
(38, 2, 12, 'Sepatu Converse Limited Edition Basket Converse Terbaru', 1300000, 'sepatu_converse_limited_edition_basket_converse_terbaru.png', 'Ready Stock', 480),
(39, 2, 11, 'Sepatu Converse Star Player 76', 1399000, 'star_player_761.png', 'Kondisi: Baru\r\nMin. Pemesanan: 1 Buah\r\nEtalase: Converse\r\nORIGINAL NEW BNIB FULLSET\r\n\r\nSize\r\n(tertera di variant product)\r\n\r\nJaga box sepatu Anda tetap aman dengan double Box\r\n\r\nOriginal gak harus mahal !\r\nJangan ada KW diantara kita\r\nFREE KAOSKAKI\r\n\r\nFor more info:\r\nInstagram : peace_sport\r\n\r\nNOTE : Khusus AnterAja dan SiCepat barang dikirim H+1', 400);

-- --------------------------------------------------------

--
-- Struktur dari tabel `slider`
--

CREATE TABLE `slider` (
  `id_slider` int(11) NOT NULL,
  `caption_slider` text NOT NULL,
  `foto_slider` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `slider`
--

INSERT INTO `slider` (`id_slider`, `caption_slider`, `foto_slider`) VALUES
(12, '<p>.</p>\r\n', 'foto11.jpg'),
(13, '<p>.</p>\r\n', 'foto21.jpg'),
(14, '<p>.</p>\r\n', 'foto3.jpg'),
(15, '<p>.</p>\r\n', 'foto4.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `kode_transaksi` varchar(50) NOT NULL,
  `id_member_beli` int(11) NOT NULL,
  `id_member_jual` int(11) NOT NULL,
  `tanggal_transaksi` datetime NOT NULL DEFAULT current_timestamp(),
  `belanja_transaksi` int(11) NOT NULL,
  `status_transaksi` enum('pesan','lunas','batal','dikirim','selesai') NOT NULL DEFAULT 'pesan',
  `ongkir_transaksi` int(11) NOT NULL,
  `total_transaksi` int(11) NOT NULL,
  `bayar_transaksi` int(11) NOT NULL,
  `distrik_pengirim` varchar(255) NOT NULL,
  `nama_pengirim` varchar(100) NOT NULL,
  `wa_pengirim` varchar(50) NOT NULL,
  `alamat_pengirim` text NOT NULL,
  `distrik_penerima` varchar(255) NOT NULL,
  `nama_penerima` varchar(100) NOT NULL,
  `wa_penerima` varchar(50) NOT NULL,
  `alamat_penerima` text NOT NULL,
  `nama_ekspedisi` varchar(100) NOT NULL,
  `layanan_ekspedisi` varchar(100) NOT NULL,
  `estimasi_ekspedisi` varchar(50) NOT NULL,
  `berat_ekspedisi` varchar(50) NOT NULL,
  `resi_ekspedisi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `kode_transaksi`, `id_member_beli`, `id_member_jual`, `tanggal_transaksi`, `belanja_transaksi`, `status_transaksi`, `ongkir_transaksi`, `total_transaksi`, `bayar_transaksi`, `distrik_pengirim`, `nama_pengirim`, `wa_pengirim`, `alamat_pengirim`, `distrik_penerima`, `nama_penerima`, `wa_penerima`, `alamat_penerima`, `nama_ekspedisi`, `layanan_ekspedisi`, `estimasi_ekspedisi`, `berat_ekspedisi`, `resi_ekspedisi`) VALUES
(18, '202507111916442071', 1, 2, '2025-07-11 19:16:44', 1399000, 'lunas', 65000, 1464000, 1464000, 'Kabupaten Cilacap Jawa Tengah', 'fullngapak segara kidul', '085878151738', 'jawa tengah cilacap', 'Kabupaten Ponorogo Jawa Timur', 'naufal fadhil asad', '088232388018', 'jawa tengah cilacap', 'Jalur Nugraha Ekakurir (JNE)', 'JNE Trucking', '65000', '400', 'jne'),
(19, '202507111919326629', 1, 2, '2025-07-11 19:19:32', 4399000, 'lunas', 65000, 4464000, 4464000, 'Kabupaten Cilacap Jawa Tengah', 'fullngapak segara kidul', '085878151738', 'jawa tengah cilacap', 'Kabupaten Ponorogo Jawa Timur', 'naufal fadhil asad', '088232388018', 'jawa tengah cilacap', 'Jalur Nugraha Ekakurir (JNE)', 'JNE Trucking', '65000', '1160', 'jne'),
(20, '202507141911372437', 1, 2, '2025-07-14 19:11:37', 1399000, 'lunas', 65000, 1464000, 1464000, 'Kabupaten Cilacap Jawa Tengah', 'fullngapak segara kidul', '085878151738', 'jawa tengah cilacap', 'Kabupaten Ponorogo Jawa Timur', 'naufal fadhil asad', '088232388018', 'jawa tengah cilacap', 'Jalur Nugraha Ekakurir (JNE)', 'JNE Trucking', '65000', '680', 'jne');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_detail`
--

CREATE TABLE `transaksi_detail` (
  `id_transaksi_detail` int(11) NOT NULL,
  `id_transaksi` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `nama_beli` varchar(255) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `jumlah_rating` int(11) DEFAULT NULL,
  `ulasan_rating` text DEFAULT NULL,
  `waktu_rating` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi_detail`
--

INSERT INTO `transaksi_detail` (`id_transaksi_detail`, `id_transaksi`, `id_produk`, `nama_beli`, `harga_beli`, `jumlah_beli`, `jumlah_rating`, `ulasan_rating`, `waktu_rating`) VALUES
(1, 1, 1, 'kemeja hitam polos', 85000, 1, NULL, NULL, NULL),
(2, 1, 2, 'celan chargo pendek', 50000, 1, NULL, NULL, NULL),
(3, 2, 13, 'Sepatu', 120000, 2, NULL, NULL, NULL),
(4, 2, 11, 'Jaket Varsity', 150000, 5, NULL, NULL, NULL),
(5, 3, 12, 'Baju Polos', 65000, 2, NULL, NULL, NULL),
(6, 4, 13, 'Sepatu', 120000, 0, NULL, NULL, NULL),
(7, 5, 8, 'Celana Chargo Pendek', 55000, 1, NULL, NULL, NULL),
(8, 6, 13, 'Sepatu', 120000, 1, NULL, NULL, NULL),
(9, 7, 11, 'Jaket Varsity', 150000, 1, NULL, NULL, NULL),
(10, 8, 12, 'Baju Polos', 65000, 4, NULL, NULL, NULL),
(11, 9, 12, 'Baju Polos', 65000, 9, NULL, NULL, NULL),
(12, 10, 11, 'Jaket Varsity', 150000, 1, NULL, NULL, NULL),
(13, 11, 12, 'Baju Polos', 65000, 1, NULL, NULL, NULL),
(14, 12, 13, 'Sepatu', 120000, 1, NULL, NULL, NULL),
(15, 13, 12, 'Baju Polos', 65000, 2, 4, 'joss', '2025-07-04 09:36:44'),
(16, 14, 13, 'Sepatu', 120000, 1, 5, 'mantap', '2025-07-09 18:49:44'),
(17, 15, 11, 'Jaket Varsity', 150000, 1, NULL, NULL, NULL),
(18, 16, 8, 'Celana Chargo Pendek', 55000, 2, NULL, NULL, NULL),
(19, 17, 8, 'Celana Chargo Pendek', 55000, 3, 5, 'mantap', '2025-07-11 15:14:10'),
(20, 18, 39, 'Sepatu Converse Star Player 76', 1399000, 1, 5, 'Barangnya Bagus Mantap!!!!!!!!!!!!!!!!!!!!!!', '2025-07-11 19:17:29'),
(21, 19, 27, 'Sepatu Converse X Shrimps Chuck Taylor All Star 70 Hi', 3000000, 1, 5, 'Keren', '2025-07-11 19:20:12'),
(22, 19, 21, 'Sepatu Wanita Converse Run Star Hike Pink Quartz High', 1399000, 1, 5, 'Mantap', '2025-07-11 19:20:12'),
(23, 20, 21, 'Sepatu Wanita Converse Run Star Hike Pink Quartz High', 1399000, 1, 5, 'cocok', '2025-07-14 19:12:28');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `artikel`
--
ALTER TABLE `artikel`
  ADD PRIMARY KEY (`id_artikel`);

--
-- Indeks untuk tabel `favorit`
--
ALTER TABLE `favorit`
  ADD PRIMARY KEY (`id_favorit`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id_member`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id_slider`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indeks untuk tabel `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  ADD PRIMARY KEY (`id_transaksi_detail`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `artikel`
--
ALTER TABLE `artikel`
  MODIFY `id_artikel` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `favorit`
--
ALTER TABLE `favorit`
  MODIFY `id_favorit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `id_member` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT untuk tabel `slider`
--
ALTER TABLE `slider`
  MODIFY `id_slider` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `transaksi_detail`
--
ALTER TABLE `transaksi_detail`
  MODIFY `id_transaksi_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
