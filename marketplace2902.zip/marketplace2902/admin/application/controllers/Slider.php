<?php
class Slider extends CI_Controller{

	function __construct(){
		parent::__construct();

		//jika tidak ada tiket
		if (!$this->session->userdata("id_admin")) {
			redirect('/', 'refresh');
		}
	}

	function index(){

		//panggil Model Mkategori
		$q = $this->load->model("Mslider");

		$data["slider"] = $this->Mslider->tampil();
		
		$this->load->view('header');
		$this->load->view('slider_tampil', $data);
		$this->load->view('footer');
	}
	function tambah() {

		//mendapatkan inputan dari formulir 
		$inputan = $this->input->post();

		//form validation nama slider wajib diisi
		$this->form_validation->set_rules("caption_slider", "Caption slider", "required");

		//atur pesan dalam b indo
		$this->form_validation->set_message("required", "%s wajib diisi");

		if ($this->form_validation->run()==TRUE ) {
			$this->load->model('Mslider');

			$this->Mslider->simpan($inputan);

			$this->session->set_flashdata('pesan_sukses', 'Data slider tersimpan');

			redirect('slider', 'refresh');
		}


		$this->load->view('header');
		$this->load->view('slider_tambah');
		$this->load->view('footer');
	}

	function hapus($id_slider){

		echo $id_slider;

		$this->load->model('Mslider');

		$this->Mslider->hapus($id_slider);

		$this->session->set_flashdata('pesan_sukses', 'slider telah dihapus');

		redirect('slider', 'refresh');
	}

	function edit($id_slider){

		$this->load->model("Mslider");
		$data['slider'] = $this->Mslider->detail($id_slider);

		$inputan = $this->input->post();

		//form validation nama slider wajib diisi
		$this->form_validation->set_rules("caption_slider", "Caption slider", "required");

		//atur pesan dalam b indo
		$this->form_validation->set_message("required", "%s wajib diisi");

		if ($this->form_validation->run()==TRUE ) {
			$this->Mslider->edit($inputan, $id_slider);

			$this->session->set_flashdata('pesan_sukses', 'slider telah diubah');

			redirect('slider', 'refresh');
		}

		$this->load->view('header');
		$this->load->view("slider_edit", $data);
		$this->load->view('footer');
	}
}
?>